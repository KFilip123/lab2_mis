package com.example.mis_lab2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
